#include <iostream>
#include "CircleList.h"
#include "Queue.h"

using namespace std;

void use_CircleList() {

    // create a CircleList in the stack
    CircleList c1; // auto memory allocation

    // add data to the CircleList
    c1.add("Jama");
    c1.add("Sally");
    c1.add("Kimbo");

    // print the data of the CircleList
    for (int i = 0; i < 3; i++) {
        cout << c1.front() << "\n";
        c1.advance();
    }
}

int main() {
    use_CircleList();
    
    return 0;
}
